#ifndef __ADR_VERSION_H
#define __ADR_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define SEE_VER_MAX_LEN			(128)
#define MAIN_VER "HLD3.0@C3701C_DDK5.0da.3.0_20130509x"

#ifdef __cplusplus
}
#endif

#endif	// __ADR_VERSION_H
