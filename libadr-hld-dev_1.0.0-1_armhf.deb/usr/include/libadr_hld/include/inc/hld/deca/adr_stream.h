/*****************************************************************************
	History:
	2004-10-29 Hudson   First Created
*****************************************************************************/

#ifndef __ADR_STREAM_H
#define __ADR_STREAM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <alidefinition/adf_hld_stream.h>


#ifdef __cplusplus
}
#endif

#endif /* STREAM_H */
