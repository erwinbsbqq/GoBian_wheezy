#ifndef __ADR_PAN_KEY_H__
#define __ADR_PAN_KEY_H__

#ifdef __cplusplus
extern "C" {
#endif


/*! @addtogroup pan
 *  @{
 */

/* Note: We remove all panel key define from pan_key.h for this file will show
 *       all of our customer's information. Please add key define in your
 *		 dedicate project directory.
 */

/*!
 @}
 */
#ifdef __cplusplus
	}
#endif

#endif /* __PAN_KEY_H__ */

