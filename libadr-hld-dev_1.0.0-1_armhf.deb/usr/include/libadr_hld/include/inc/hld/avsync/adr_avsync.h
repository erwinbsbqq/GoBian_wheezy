#ifndef __ADR_AVSYNC_H__
#define __ADR_AVSYNC_H__

#include <alidefinition/adf_avsync.h>

#endif
