#ifndef	__ADR_VPOAPI_H_
#define	__ADR_VPOAPI_H_

#include <adr_mediatypes.h>
#include <adr_basic_types.h>
#include <alidefinition/adf_vpo.h>
#endif

