/****************************************************************************
 *
 *  ALi (ShangHai) Corporation, All Rights Reserved. 2011 Copyright (C)
 *
 *  File: decv_avs.h
 *
 *  Description: head file for avc video decoder device management.
 *
 *  History:
 *      Date        Author         Version   Comment
 *      ====    ======      =======   =======
 ****************************************************************************/
#ifndef __ADR_DECV_AVS_H_
#define  __ADR_DECV_AVS_H_

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif  

