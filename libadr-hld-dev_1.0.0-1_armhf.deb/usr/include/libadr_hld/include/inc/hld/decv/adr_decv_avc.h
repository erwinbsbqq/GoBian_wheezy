/****************************************************************************
 *
 *  ALi (Zhuhai) Corporation, All Rights Reserved. 2007 Copyright (C)
 *
 *  File: decv_avc.h
 *
 *  Description: head file for avc video decoder device management.
 *
 *  History:
 *      Date        Author         Version   Comment
 *      ====        ======         =======   =======
 *  1.  2007.7.271  Michael	Xie	     0.0.1   Create
 ****************************************************************************/
#ifndef  __ADR_DECV_AVC_H_
#define  __ADR_DECV_AVC_H_

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif  /* _DECV_H_*/

