#ifndef __DRIVERS_ALI_RPC_HLD_GMA_H
#define __DRIVERS_ALI_RPC_HLD_GMA_H

#include <alidefinition/adf_gma.h>

#endif

