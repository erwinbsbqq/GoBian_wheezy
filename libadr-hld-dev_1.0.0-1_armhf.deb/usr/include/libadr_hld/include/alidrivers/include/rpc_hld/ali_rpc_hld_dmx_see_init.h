#ifndef  _ALI_RPC_HLD_DMX_H_
#define  _ALI_RPC_HLD_DMX_H_

#include "ali_rpc_hld.h"

void sed_dmx_attach(UINT32 dummy);


#endif  /*_ALI_RPC_HLD_DSC_H_*/






