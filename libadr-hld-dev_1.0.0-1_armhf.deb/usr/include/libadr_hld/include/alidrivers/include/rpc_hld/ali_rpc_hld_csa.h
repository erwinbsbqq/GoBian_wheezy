

void ali_m36_csa_see_init(void);



