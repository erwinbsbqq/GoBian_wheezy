#ifndef __DRIVERS_ALI_RPC_HLD_AVSYNC_H
#define __DRIVERS_ALI_RPC_HLD_AVSYNC_H

#include "ali_rpc_hld.h"
#include <alidefinition/adf_avsync.h>

#endif
