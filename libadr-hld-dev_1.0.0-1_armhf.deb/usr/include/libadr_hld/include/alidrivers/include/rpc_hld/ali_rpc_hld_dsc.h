#ifndef  _ALI_RPC_HLD_DSC_H_
#define  _ALI_RPC_HLD_DSC_H_

#include "ali_rpc_hld.h"

void ali_m36_dsc_see_init(void);


#endif  /*_ALI_RPC_HLD_DSC_H_*/
