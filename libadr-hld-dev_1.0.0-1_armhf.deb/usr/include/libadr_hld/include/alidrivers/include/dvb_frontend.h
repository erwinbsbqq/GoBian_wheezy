#ifndef _DVB_FRONTEND_H_
#define _DVB_FRONTEND_H_

#include <linux/dvb/frontend.h>
#include "dvb_frontend_common.h"

#endif
