#ifndef _ALI_NETLINK_H_
#define _ALI_NETLINK_H_

#include <linux/netlink.h>
#include "ali_netlink_common.h"

#endif
