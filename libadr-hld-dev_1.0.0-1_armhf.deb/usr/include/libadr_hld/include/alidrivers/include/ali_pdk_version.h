#ifndef __ALI_PDK_VERSION_H
#define __ALI_PDK_VERSION_H


static volatile unsigned char  ali_driver_ver[] = "ALIPDK4.0@BASELINE5.0dx.4.0_AUI_C_20130812";


#endif	// __ALI_PDK_VERSION_H