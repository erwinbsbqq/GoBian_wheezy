/**@file
 *  (c) Copyright 2013-2999  ALi Corp. ZHA Linux SDK Team (alitech.com)
 *  All rights reserved 
 *
 *  @file               ali_media_common.h
 *  @brief              
 *
 *  @version            1.0
 *  @date               02/25/2014 02:50:55 PM
 *  @revision           none
 *
 *  @author             Ze Hong <ze.hong@alitech.com>
 */

#ifndef __ALI_MEDIA_COMMON_H_
#define __ALI_MEDIA_COMMON_H_

#ifdef __cplusplus
extern "C"
{
#endif
#include "alidefinition/adf_media.h"

#ifdef __cplusplus
}
#endif

#endif
