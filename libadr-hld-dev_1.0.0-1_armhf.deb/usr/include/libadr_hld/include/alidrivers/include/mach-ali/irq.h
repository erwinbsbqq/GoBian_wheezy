#ifndef _ARCH_ASM_MACH_IRQ_H_
#define _ARCH_ASM_MACH_IRQ_H_


#define NR_IRQS	256

#include_next <irq.h>

#endif /* _ARCH_ASM_MACH_IRQ_H_ */
