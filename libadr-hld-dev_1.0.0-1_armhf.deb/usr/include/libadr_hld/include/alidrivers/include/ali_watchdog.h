#ifndef _ALI_WATCHDOG_H_
#define _ALI_WATCHDOG_H_

#include <linux/watchdog.h>
#include "ali_watchdog_common.h"

#endif
