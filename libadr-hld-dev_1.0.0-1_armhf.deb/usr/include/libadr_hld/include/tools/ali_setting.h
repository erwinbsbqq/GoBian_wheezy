#ifndef __ALI_SETTING_H
#define __ALI_SETTING_H

#include <hld/decv/adr_decv.h>
#include <hld/dis/adr_vpo.h>

#define VDAC_USE_CVBS_TYPE      CVBS_1
#define VDAC_USE_RGB_TYPE       RGB_1
#define VDAC_USE_YUV_TYPE       YUV_1
#define VDAC_USE_SVIDEO_TYPE    SVIDEO_1

#define YUV_DAC_Y               DAC2
#define YUV_DAC_U               DAC1
#define YUV_DAC_V               DAC0
#define CVBS_DAC		    DAC3

#define CVBS_OPEN    1
#define CVBS_CLOSE    0

// resolution type
enum SYSTEM_RES
{
    RESOLUTION_480I=0,
    RESOLUTION_576I=1,
    RESOLUTION_480P=2,
    RESOLUTION_576P=3,
    RESOLUTION_720P50=4,
    RESOLUTION_720P60=5,
    RESOLUTION_1080I25=6,
    RESOLUTION_1080I30=7,
    RESOLUTION_1080P24=8,
    RESOLUTION_1080P25=9,
    RESOLUTION_1080P30=10,
    RESOLUTION_1080P50=11,
    RESOLUTION_1080P60=12,
    RESOLUTION_VGA=13,
    RESOLUTION_XGA=14,
    RESOLUTION_WXGA=15,
    RESOLUTION_4096X2160_24=16,
    RESOLUTION_3840X2160_24=17, 
    RESOLUTION_3840X2160_25=18,  
    RESOLUTION_3840X2160_30=19,
    RESOLUTION_SMART_OUTPUT =20,
    RESOLUTION_UNCONNECT =21,
    RESOLUTION_UNSUPPORT=22
};

//display type for brightness,saturation,sharpnes,contrast
enum
{
    DISPLAY_VIDEO_OSD=0,    //only video layer
    DISPLAY_VIDEO,         //only osd layer
    DISPLAY_OSD //both video and osd layer
};

enum
{
    DIGITAL_MODE_PCM=0,    //PCM
    DIGITAL_MODE_BS,         //bypass
    DIGITAL_MODE_51BS //5.1bypass
};


//MODE FOR 3D
enum
{
    DISPLAY_3D_DISABLE=0,       //CASE 1: 3d DISABLE
    SIDE_BY_SIDE=1  ,                 //CASE 2: 3D LEFT-RIGHT
    TOP_BOTTOM=2  ,                     //CASE 3: 3D OVER-UNDER
    DISPLAY_2D_TO_3D=3 ,        //CASE 4: 2D TO 3D
    RED_BLUE=4                          //CASE 5: RED_BLUE
};

void ali_device_open();
void setResolution( int resolution);
int getResolution();
int get_tvsys_and_progress(int res, enum TVSystem * tvsys, BOOL * bprogressive);
BOOL vdac_close_enable();

#endif

